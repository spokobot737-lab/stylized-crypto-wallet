import {_electron as electron} from 'playwright';
import {build} from 'esbuild';
import {copyFile,mkdir,writeFile,readFile} from 'node:fs/promises';
import assert from 'node:assert/strict';
await mkdir('tests/.generated',{recursive:true});await mkdir('docs',{recursive:true});
const fixture=(await readFile('tests/support/ui-main.ts','utf8')).replace('app.disableHardwareAcceleration();','(async()=>{app.disableHardwareAcceleration();')+'\n})().catch(e=>{console.error(e);app.exit(1);});';await build({stdin:{contents:fixture,resolveDir:process.cwd()+'/tests/support',sourcefile:'ui-main.ts',loader:'ts'},outfile:'tests/.generated/ui-main.cjs',bundle:true,platform:'node',format:'cjs',packages:'external',target:'node22'});await copyFile('electron/assets/media-worker.cjs','tests/.generated/media-worker.cjs');
const application=await electron.launch({args:['tests/.generated/ui-main.cjs',...(process.platform==='linux'?['--no-sandbox','--ozone-platform=headless','--ozone-override-screen-size=1440,1080','--disable-dev-shm-usage']:[])],timeout:60000});
const errors=[];
async function contrast(page,label){
 await page.waitForTimeout(100);const issues=await page.evaluate(()=>{
  const canvas=document.createElement('canvas');canvas.width=canvas.height=1;const ctx=canvas.getContext('2d',{willReadFrequently:true});
  const rgba=value=>{ctx.clearRect(0,0,1,1);ctx.fillStyle=value;ctx.fillRect(0,0,1,1);return [...ctx.getImageData(0,0,1,1).data].map((n,i)=>i===3?n/255:n);};
  const blend=(top,bottom)=>[0,1,2].map(i=>top[i]*top[3]+bottom[i]*(1-top[3]));
  const lum=rgb=>{const x=rgb.map(n=>{n/=255;return n<=.04045?n/12.92:((n+.055)/1.055)**2.4;});return .2126*x[0]+.7152*x[1]+.0722*x[2];};
  const selectors=['.asset-balance','.asset-address','.asset-footer button','.profile-avatar','.profile-dropdown>button','.sidebar nav button.active','.wallet-selector select','.wallet-heading .eyebrow','.topbar .tag','.muted','.activity-description h3','.network-name','.activity-subline','.transaction-status','.activity-peer','.activity-extra','.chat-title small','.chat-peer-header small','.chat-message footer','.chat-contacts small','.chat-disclaimer','.sidebar-settings','.field>span','.field>small','.note','button.primary'];
  const issues=[];
  for(const selector of selectors)for(const el of document.querySelectorAll(selector)){
   const style=getComputedStyle(el);if(!el.getClientRects().length||style.visibility==='hidden'||el.disabled)continue;
   const ancestors=[];let opacity=1;for(let node=el;node;node=node.parentElement){ancestors.unshift(node);opacity*=Number(getComputedStyle(node).opacity);}
   let bg=[16,17,22];for(const node of ancestors)bg=blend(rgba(getComputedStyle(node).backgroundColor),bg);
   const fg=rgba(style.color);fg[3]*=opacity;const actual=blend(fg,bg),l1=lum(actual),l2=lum(bg),ratio=(Math.max(l1,l2)+.05)/(Math.min(l1,l2)+.05);
   const large=parseFloat(style.fontSize)>=24||(parseFloat(style.fontSize)>=18.66&&Number(style.fontWeight)>=700);const threshold=large?3:4.5;
   if(ratio<threshold)issues.push({selector,ratio:Number(ratio.toFixed(2)),text:(el.textContent||'').trim().slice(0,45)});
  }
  return issues;
 });assert.deepEqual(issues,[],`Contrast regression (${label}): ${JSON.stringify(issues)}`);
}
try{
 const page=await application.firstWindow({timeout:60000});page.setDefaultTimeout(15000);page.on('pageerror',e=>errors.push(e.message));await page.getByRole('button',{name:'Chat',exact:true}).click();await page.locator('.chat-contacts>button').first().click();await page.getByText('Dziękuję. Spotkajmy się jutro o 10:00.',{exact:true}).waitFor();
 const navigation=await page.locator('.sidebar nav button').allTextContents();assert.deepEqual(navigation.map(x=>x.trim()),['Twój portfel','NFT','Chat']);assert.equal(await page.locator('.sidebar-bottom').getByRole('button',{name:'Ustawienia',exact:true}).count(),1);
 assert.equal(await page.evaluate(()=>typeof window.require),'undefined');
 const separator=page.getByRole('separator',{name:'Szerokość listy rozmów'});await separator.focus();await separator.press('ArrowRight');assert.equal(await separator.getAttribute('aria-valuenow'),'250');
 const box=await separator.boundingBox();await page.mouse.move(box.x+3,box.y+20);await page.mouse.down();await page.mouse.move(box.x+43,box.y+20);await page.mouse.up();assert.equal(await separator.getAttribute('aria-valuenow'),'290');
 const composer=page.getByRole('separator',{name:'Wysokość pola wiadomości'});await composer.press('ArrowUp');assert.equal(await composer.getAttribute('aria-valuenow'),'135');
 await page.reload();await page.getByRole('button',{name:'Chat',exact:true}).click();await page.locator('.chat-contacts>button').first().click();assert.equal(await page.getByRole('separator',{name:'Szerokość listy rozmów'}).getAttribute('aria-valuenow'),'290');
 const timeline=page.locator('.chat-timeline');await timeline.evaluate(el=>{el.scrollTop=0;el.dispatchEvent(new Event('scroll'));});await application.evaluate(()=>globalThis.__frameFixture.sendRemote());await page.getByRole('button',{name:/Nowe wiadomości: 1/}).waitFor({timeout:10000});assert.equal(await timeline.evaluate(el=>el.scrollTop),0);await page.getByRole('button',{name:/Nowe wiadomości: 1/}).click();assert.ok(await timeline.evaluate(el=>el.scrollTop>0));
 await timeline.evaluate(el=>{el.scrollTop=0;el.dispatchEvent(new Event('scroll'));});await page.getByLabel('Wiadomość tekstowa',{exact:true}).fill('Własna wiadomość testowa');await page.getByRole('button',{name:'Wyślij',exact:true}).click();await page.getByText('Własna wiadomość testowa',{exact:true}).waitFor();await page.waitForTimeout(100);assert.ok(await timeline.evaluate(el=>el.scrollHeight-el.scrollTop-el.clientHeight<20));
 const png=await application.evaluate(()=>globalThis.__frameFixture.png);await writeFile('tests/.generated/avatar.png',Buffer.from(png.split(',')[1],'base64'));
 await page.locator('input[type=file]').first().setInputFiles('tests/.generated/avatar.png');await page.locator('.chat-attachment-preview img').waitFor();await page.getByLabel('Wiadomość tekstowa',{exact:true}).fill('Obraz testowy');await page.getByRole('button',{name:'Wyślij',exact:true}).click();await page.getByText('Obraz testowy',{exact:true}).waitFor();await page.getByRole('button',{name:'Powiększ obraz'}).last().click();await page.locator('.chat-zoom').waitFor();await page.getByRole('button',{name:'Zamknij',exact:true}).click();
 for(const theme of ['obsidian','pop','chroma','alien']){
  await page.evaluate(theme=>{const p=JSON.parse(localStorage.getItem('frame:preferences')||'{}');localStorage.setItem('frame:preferences',JSON.stringify({...p,theme,motionStyle:'fluid',motion:true}));},theme);await page.reload();await page.getByRole('button',{name:'Chat',exact:true}).click();await page.locator('.chat-contacts>button').first().click();await page.locator('.chat-message').first().waitFor();await contrast(page,theme);if(theme==='alien')for(const accent of ['violet','cyan','lime','pink']){await page.evaluate(a=>document.documentElement.dataset.accent=a,accent);await contrast(page,'alien-'+accent);}if(theme==='obsidian')await page.screenshot({path:'docs/chat-0.6.0.png',fullPage:true});
 }
 for(const style of ['hexagons','fluid','off']){await page.evaluate(style=>{const p=JSON.parse(localStorage.getItem('frame:preferences'));localStorage.setItem('frame:preferences',JSON.stringify({...p,motionStyle:style,motion:style!=='off'}));},style);await page.reload();await page.getByRole('button',{name:'Chat',exact:true}).click();await page.locator('.chat-contacts>button').first().click();assert.equal(await page.locator('html').getAttribute('data-motion-style'),style);}
 await page.emulateMedia({reducedMotion:'reduce'});assert.equal(await page.locator('.content-body').evaluate(el=>getComputedStyle(el,'::before').display),'none');await page.emulateMedia({reducedMotion:'no-preference'});
 await application.evaluate(({BrowserWindow})=>BrowserWindow.getAllWindows()[0].setSize(720,720));await page.getByRole('button',{name:'Wróć do listy rozmów'}).click();assert.equal(await page.locator('.chat-conversation').isVisible(),false);await page.locator('.chat-contacts>button').first().click();assert.equal(await page.locator('.chat-contacts').isVisible(),false);assert.ok(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth));await page.screenshot({path:'docs/chat-small-0.6.0.png',fullPage:true});
 await application.evaluate(({BrowserWindow})=>BrowserWindow.getAllWindows()[0].setSize(1440,1080));await page.getByRole('button',{name:'NFT',exact:true}).click();await page.getByTestId('nft-ETH').waitFor();await page.getByTestId('nft-SOL').waitFor();await page.getByTestId('nft-ETH').locator('.nft-thumbnail img').waitFor();await page.getByTestId('nft-SOL').locator('.nft-thumbnail img').waitFor();await page.screenshot({path:'docs/nft-all-0.6.0.png',fullPage:true});
 assert.deepEqual(errors,[]);console.log('UI 0.6.0: IPC, chat, images, resize, scrolling, persistence, mobile, themes, reduced motion, NFT ETH/SOL passed.');
}catch(e){try{const p=await application.firstWindow();await p.screenshot({path:'tests/.generated/failure.png',fullPage:true});console.log(await p.evaluate(()=>({size:[innerWidth,innerHeight],body:document.body.innerText.slice(-2500),chat:[...document.querySelectorAll('.chat-workspace,.chat-contacts,.chat-list-heading,.frame-chat')].map(e=>({class:e.className,rect:e.getBoundingClientRect().toJSON()}))})));}catch{}throw e;}finally{await application.close();}
